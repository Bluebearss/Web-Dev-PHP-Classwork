<!DOCTYPE HTML>
<!-- Brian Zhu -->
<html>
	<head>
		<title></title>
		<style>
		</style>
		<script>
		</script>
	</head>
	
	<body>
		PERSONAL INFORMATION:
		<?php
			//$_POST
			//$_GET
			echo $_POST["first"];
			echo $_POST["last"];
			echo $_POST["gender"];
			echo $_POST["This is my first Internet Quiz!"];
		?>
	</body>
</html>